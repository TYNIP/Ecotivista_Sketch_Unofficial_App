export default function ComingSoon(){
    return (
        <div style={{'height':'50vh', 'width':'100%', 'display': 'flex', 'justifyContent': 'center', 'alignItems':'center'}}>
            <p style={{'fontSize':'5vh'}}>PRÓXIMAMENTE</p>
        </div>
    )
}