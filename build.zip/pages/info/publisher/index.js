import ArticlePublisher from '@/features/ArticlePublisher/ArticlePublisher';

export default function Publisher(){
  return (
    <section>
      <ArticlePublisher />
    </section>
  );
};
