exports.id=3414,exports.ids=[3414],exports.modules={7251:e=>{e.exports={notification:"styles_notification__LXbw1",start:"styles_start__Uld4O",success:"styles_success__sqwVo",error:"styles_error__jCB7Q"}},2087:(e,t,r)=>{"use strict";r.d(t,{Z:()=>u});var s=r(997),i=r(1664),o=r.n(i),n=r(7518),l=r.n(n),a=r(9529);let c=l().footer`
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  padding: 1rem 2rem;
  background-color: white;
  color: black;
  width: 100%;
`,d=l().div`
border-top: 0.4px solid rgba(0,0,0,0.2);
border-bottom: 0.4px solid rgba(0,0,0,0.2);
display: flex;
flex-wrap: wrap;
justify-content: center;
width: 100%;
`,h=l().div`
display: flex;
flex-direction: column;
padding: 2%;
margin: 0 0.5%;
p {
font-size: 1rem;
font-weight: bold;
}
a{
font-size: 0.8rem;
}
a:hover{
color: #25C660;
}
`,x=l().p`
  margin: 0;
  padding-top: 1%
`,u=()=>(0,s.jsxs)(c,{children:[(0,s.jsxs)(d,{children:[(0,s.jsxs)(h,{children:[s.jsx("p",{children:"Ecotivista"}),s.jsx(o(),{href:"/about",children:"Sobre Ecotivista"}),s.jsx(o(),{href:"/about/journalism",children:"Periodismo"}),s.jsx(o(),{href:"/about/activism",children:"Activismo"}),s.jsx(o(),{href:"/about/education",children:"Educaci\xf3n"})]}),(0,s.jsxs)(h,{children:[s.jsx("p",{children:"Recursos"}),s.jsx(o(),{href:"/terms/comenzando-con-ecotivista.pdf",children:"Comenzando"}),s.jsx(o(),{href:"/terms/como-usar-publicista.pdf",children:"\xbfC\xf3mo usar Publicista?"})]}),(0,s.jsxs)(h,{children:[s.jsx("p",{children:"Contactanos"}),s.jsx(o(),{href:"/about/contact",children:"Mandanos un Email"})]}),(0,s.jsxs)(h,{children:[s.jsx("p",{children:"Terminos de Uso"}),s.jsx(o(),{href:"/terms/terminos-y-condiciones-ecotivista.pdf",children:"Terminos del Servicio"}),s.jsx(o(),{href:"/terms/politica-de-privacidad-ecotivista.pdf",children:"Politica de Privacidad"}),s.jsx(o(),{href:"/terms-service/config-cookies",children:"Configuraci\xf3n de Cookies"})]}),(0,s.jsxs)(h,{children:[s.jsx("p",{children:"Redes Sociales"}),s.jsx(a.Z,{links:{linkedIn:"company/ecotivista",instagram:"ecotivista_/",yt:"@ecotivista?si=W4jIwKrRgtaSg63y",tiktok:"@ecotivista"}})]})]}),(0,s.jsxs)(x,{children:["ecotivista.org \xa9 ",new Date().getFullYear()," Ecotivista. All rights reserved."]})]})},9046:(e,t,r)=>{"use strict";r.d(t,{Z:()=>N});var s=r(997),i=r(1664),o=r.n(i),n=r(7518),l=r.n(n),a=r(6689),c=r(9332);let d=l().div`
position: fixed;
top: 70px;
z-index: 40000;
display: flex;
flex-direction: column;
background-color: white;
border: 0.5px solid rgba(0,0,0,0.1);
max-height: 100vh;
padding: 0;
margin-left: 2%;
border-radius: 10px 10px 0 0;

a {
    text-decoration: none;
    font-weight: bold;
    color: black;
    padding: 10px 50px 10px 20px;
    border-bottom: 1px solid rgba(0,0,0,0.1);
    &:hover {
      background-color: #E9E9E9;
      transition:200ms;
    }
`,h=l().div`
  position: fixed;
  z-index: 30000;
  background-color:rgba(0,0,0, 0.1);
  width: 100%;
  height: 100% !important;
`,x=({setOptions:e})=>(0,s.jsxs)(s.Fragment,{children:[(0,s.jsxs)(d,{className:"show",children:[s.jsx(o(),{href:"/",onClick:()=>e(!1),className:"show",children:"Inicio"}),s.jsx(o(),{href:"/about",onClick:()=>e(!1),className:"show",children:"Ecotivista"}),s.jsx(o(),{href:"/articles",onClick:()=>e(!1),className:"show",children:"Articulos"}),s.jsx(o(),{href:"/education",onClick:()=>e(!1),className:"show",children:"Educaci\xf3n"}),s.jsx(o(),{href:"/forums",onClick:()=>e(!1),className:"show",children:"Foros"}),s.jsx(o(),{href:"/events",onClick:()=>e(!1),className:"show",children:"Eventos"})]}),s.jsx(h,{onClick:()=>e(!1),className:"show"})]});var u=r(1163),C=r(7026);let p=l().div`
position: fixed;
top: 70px;
right: 0;
z-index: 40000;
display: flex;
flex-direction: column;
background-color: white;
border: 0.5px solid rgba(0,0,0,0.1);
max-height: 100vh;
padding: 0;
margin-right: 2%;
border-radius: 10px 10px 0 0;

a, button {
    text-decoration: none;
    font-weight: bold;
    color: black;
    padding: 10px 50px 10px 20px;
    border-bottom: 1px solid rgba(0,0,0,0.1);
    &:hover {
      background-color: #E9E9E9;
      transition:200ms;
    }
`,j=l().div`
  position: fixed;
  z-index: 30000;
  background-color:rgba(0,0,0, 0.1);
  width: 100%;
  height: 100vh;
`,g=l().button`
margin: 0;
`,k=({setOptions:e})=>{let t=(0,u.useRouter)(),{setIsAuthenticated:r,setUsername:i,setEmail:n,setId:l}=(0,C.a)(),a=async()=>{try{await fetch("/api/auth/logout",{method:"POST"})&&(r(!1),i(""),n(""),l(""),e(!1),t.push("/"))}catch(e){console.error("Error closing session")}};return(0,s.jsxs)(s.Fragment,{children:[(0,s.jsxs)(p,{children:[s.jsx(o(),{href:"/info/profile",onClick:()=>e(!1),children:"Perfil "}),s.jsx(o(),{href:"/info/articles",onClick:()=>e(!1),children:"Mis Articulos "}),s.jsx(o(),{href:"/info/articles/publisher",onClick:()=>e(!1),children:"Publicista "}),s.jsx(g,{onClick:()=>a(),children:"Cerrar Sesi\xf3n"})]}),s.jsx(j,{onClick:()=>e(!1)})]})},w=({change:e})=>(0,s.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",width:"24",height:"24",color:"#000000",fill:"none",style:{margin:"0 5px"},className:"hover show",onClick:()=>e(),children:[s.jsx("path",{d:"M6 4C6 5.10457 5.10457 6 4 6C2.89543 6 2 5.10457 2 4C2 2.89543 2.89543 2 4 2C5.10457 2 6 2.89543 6 4Z",stroke:"currentColor","stroke-width":"1.5"}),s.jsx("path",{d:"M22 4C22 5.10457 21.1046 6 20 6C18.8954 6 18 5.10457 18 4C18 2.89543 18.8954 2 20 2C21.1046 2 22 2.89543 22 4Z",stroke:"currentColor","stroke-width":"1.5"}),s.jsx("path",{d:"M22 20C22 21.1046 21.1046 22 20 22C18.8954 22 18 21.1046 18 20C18 18.8954 18.8954 18 20 18C21.1046 18 22 18.8954 22 20Z",stroke:"currentColor","stroke-width":"1.5"}),s.jsx("path",{d:"M6 20C6 21.1046 5.10457 22 4 22C2.89543 22 2 21.1046 2 20C2 18.8954 2.89543 18 4 18C5.10457 18 6 18.8954 6 20Z",stroke:"currentColor","stroke-width":"1.5"}),s.jsx("path",{d:"M16.5 9C16.5 8.53406 16.5 8.30109 16.4239 8.11732C16.3224 7.87229 16.1277 7.67761 15.8827 7.57612C15.6989 7.5 15.4659 7.5 15 7.5H9C8.53406 7.5 8.30109 7.5 8.11732 7.57612C7.87229 7.67761 7.67761 7.87229 7.57612 8.11732C7.5 8.30109 7.5 8.53406 7.5 9C7.5 9.46594 7.5 9.69891 7.57612 9.88268C7.67761 10.1277 7.87229 10.3224 8.11732 10.4239C8.30109 10.5 8.53406 10.5 9 10.5H15C15.4659 10.5 15.6989 10.5 15.8827 10.4239C16.1277 10.3224 16.3224 10.1277 16.4239 9.88268C16.5 9.69891 16.5 9.46594 16.5 9Z",stroke:"currentColor","stroke-width":"1.5","stroke-linecap":"round","stroke-linejoin":"round"}),s.jsx("path",{d:"M16.5 15C16.5 14.5341 16.5 14.3011 16.4239 14.1173C16.3224 13.8723 16.1277 13.6776 15.8827 13.5761C15.6989 13.5 15.4659 13.5 15 13.5H9C8.53406 13.5 8.30109 13.5 8.11732 13.5761C7.87229 13.6776 7.67761 13.8723 7.57612 14.1173C7.5 14.3011 7.5 14.5341 7.5 15C7.5 15.4659 7.5 15.6989 7.57612 15.8827C7.67761 16.1277 7.87229 16.3224 8.11732 16.4239C8.30109 16.5 8.53406 16.5 9 16.5H15C15.4659 16.5 15.6989 16.5 15.8827 16.4239C16.1277 16.3224 16.3224 16.1277 16.4239 15.8827C16.5 15.6989 16.5 15.4659 16.5 15Z",stroke:"currentColor","stroke-width":"1.5","stroke-linecap":"round","stroke-linejoin":"round"})]}),m=()=>(0,s.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",width:"24",height:"24",color:"#000000",fill:"none",style:{margin:"0 5px"},className:"hover",children:[s.jsx("path",{d:"M2.52992 14.394C2.31727 15.7471 3.268 16.6862 4.43205 17.1542C8.89481 18.9486 15.1052 18.9486 19.5679 17.1542C20.732 16.6862 21.6827 15.7471 21.4701 14.394C21.3394 13.5625 20.6932 12.8701 20.2144 12.194C19.5873 11.2975 19.525 10.3197 19.5249 9.27941C19.5249 5.2591 16.1559 2 12 2C7.84413 2 4.47513 5.2591 4.47513 9.27941C4.47503 10.3197 4.41272 11.2975 3.78561 12.194C3.30684 12.8701 2.66061 13.5625 2.52992 14.394Z",stroke:"currentColor","stroke-width":"1.5","stroke-linecap":"round","stroke-linejoin":"round"}),s.jsx("path",{d:"M9 21C9.79613 21.6219 10.8475 22 12 22C13.1525 22 14.2039 21.6219 15 21",stroke:"currentColor","stroke-width":"1.5","stroke-linecap":"round","stroke-linejoin":"round"})]}),f=({router:e})=>(0,s.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",width:"24",height:"24",color:"#000000",fill:"none",style:{margin:"0 5px"},className:"hover",onClick:()=>e.push("/articles"),children:[s.jsx("path",{d:"M14 14L16.5 16.5",stroke:"currentColor","stroke-width":"1.5","stroke-linejoin":"round"}),s.jsx("path",{d:"M16.4333 18.5252C15.8556 17.9475 15.8556 17.0109 16.4333 16.4333C17.0109 15.8556 17.9475 15.8556 18.5252 16.4333L21.5667 19.4748C22.1444 20.0525 22.1444 20.9891 21.5667 21.5667C20.9891 22.1444 20.0525 22.1444 19.4748 21.5667L16.4333 18.5252Z",stroke:"currentColor","stroke-width":"1.5","stroke-linecap":"round"}),s.jsx("path",{d:"M16 9C16 5.13401 12.866 2 9 2C5.13401 2 2 5.13401 2 9C2 12.866 5.13401 16 9 16C12.866 16 16 12.866 16 9Z",stroke:"currentColor","stroke-width":"1.5","stroke-linejoin":"round"})]}),v=({change:e})=>(0,s.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",width:"24",height:"24",color:"#000000",fill:"none",style:{margin:"0 5px"},className:"hover",onClick:()=>e(),children:[s.jsx("path",{d:"M7.78256 17.1112C6.68218 17.743 3.79706 19.0331 5.55429 20.6474C6.41269 21.436 7.36872 22 8.57068 22H15.4293C16.6313 22 17.5873 21.436 18.4457 20.6474C20.2029 19.0331 17.3178 17.743 16.2174 17.1112C13.6371 15.6296 10.3629 15.6296 7.78256 17.1112Z",stroke:"currentColor","stroke-width":"1.5","stroke-linecap":"round","stroke-linejoin":"round"}),s.jsx("path",{d:"M15.5 10C15.5 11.933 13.933 13.5 12 13.5C10.067 13.5 8.5 11.933 8.5 10C8.5 8.067 10.067 6.5 12 6.5C13.933 6.5 15.5 8.067 15.5 10Z",stroke:"currentColor","stroke-width":"1.5"}),s.jsx("path",{d:"M2.854 16C2.30501 14.7664 2 13.401 2 11.9646C2 6.46129 6.47715 2 12 2C17.5228 2 22 6.46129 22 11.9646C22 13.401 21.695 14.7664 21.146 16",stroke:"currentColor","stroke-width":"1.5","stroke-linecap":"round"})]}),b=l().header`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem 2rem;
  background-color: white;
  border: 1px solid rgba(0,0,0, 0.1);
  position: sticky;
  z-index: 20000; 
  top: 0;
  height: 70px;
`,y=l().div`
display: flex;
align-items: center;
justify-content: center;
flex-direction: column;
width: 100%;
padding: 1% 2%;

`,E=l().div`
  font-size: 6vh !important;
  font-weight: bold;
  padding: 0 2%
`,M=l().nav`
display: flex;
justify-content: center;
align-items: center;
  a {
    text-decoration: none;
    font-weight: bold;
    color: black;
    padding: 5px 20px;
    margin: 0 5px;

    &:hover {
      background-color: #E9E9E9;
      border-radius: 20px;
      transition:200ms;
    }
  }
`,Z=l().div`
display: flex;
justify-content: center;
align-items: center;
`,S=l().p`
font-style: italic;
width: 100%;
text-align: center;
`,N=({isAuthenticated:e})=>{let t=(0,c.useRouter)(),[r,i]=(0,a.useState)(!1),[n,l]=(0,a.useState)(!1);return(0,s.jsxs)(s.Fragment,{children:[(0,s.jsxs)(b,{children:[(0,s.jsxs)(M,{children:[(0,s.jsxs)(Z,{children:[s.jsx(w,{change:function(){i(!r),l(!1)}}),s.jsx(m,{}),s.jsx(f,{router:t})]}),(0,s.jsxs)("div",{className:"hide",onClick:()=>i(!1),children:[s.jsx(o(),{href:"/",children:"Inicio"}),s.jsx(o(),{href:"/about",children:"Ecotivista"}),s.jsx(o(),{href:"/articles",children:"Articulos"}),s.jsx(o(),{href:"/education",children:"Educaci\xf3n"}),s.jsx(o(),{href:"/forums",children:"Foros"}),s.jsx(o(),{href:"/events",children:"Eventos"})]})]}),(0,s.jsxs)(M,{children:[!e&&s.jsx(o(),{href:"/login",children:"Log In"}),e&&s.jsx(Z,{children:s.jsx(v,{change:function(){l(!n),i(!1)}})})]})]}),r&&s.jsx(x,{setOptions:i}),n&&s.jsx(k,{setOptions:l}),(0,s.jsxs)(y,{children:[s.jsx(E,{id:"mainName",children:s.jsx(o(),{href:"/",children:"ECOTIVISTA"})}),s.jsx(S,{children:s.jsx(o(),{href:"/",children:"La Casa del Periodismo y Activismo Independiente"})})]})]})}},214:(e,t,r)=>{"use strict";r.d(t,{Z:()=>x});var s=r(997),i=r(1664),o=r.n(i),n=r(7518),l=r.n(n),a=r(6689),c=r(9332);let d=l().div`
  display: flex;
  width: 100%;
  align-items: center;
  justify-content: center;
  border: 1px solid rgba(0,0,0, 0.1);
  position: sticky;
  z-index: 20000;
  top: 55px;
  background-color: white;
  padding: 0 20px 0 20px;
`,h=l().nav`
  display: flex;
  justify-content: center;
  align-items: center;
  overflow: auto;
  scrollbar-width: thin; 
  scrollbar-color: white white;
  scrollbar-style: none;

  a {
    text-decoration: none;
    color: black;
    padding: 5px 20px;
    margin: 0 5px;
    white-space: nowrap;

    &:hover {
      background-color: #E9E9E9;
      transition: 200ms;
    }
  }
`,x=()=>{let[e,t]=(0,a.useState)([]),r=(0,c.usePathname)();return(0,a.useEffect)(()=>{t(function(e){return"about"===(e=e.split("/"))[1]?[{path:"Manifesto",link:"/about"},{path:"Equipo",link:"/about/team"},{path:"Periodismo",link:"/about/journalism"},{path:"Activismo",link:"/about/activism"},{path:"Educaci\xf3n",link:"/about/education"},{path:"Contactanos",link:"/about/contact"}]:[{path:"Recientes",link:"/articles?sort=recents"},{path:"Descubre",link:"/articles?sort=discover"},{path:"Sugeridos",link:"/articles/suggestions"},{path:"Ecotivista",link:"/users/ECOTIVISTA"}]}(r))},[r]),s.jsx(d,{children:s.jsx(h,{children:e.map((e,t)=>s.jsx(o(),{href:`${e.link}`,children:e.path},t))})})}},5371:(e,t,r)=>{"use strict";r.a(e,async(e,s)=>{try{r.d(t,{Z:()=>m});var i=r(997),o=r(6689),n=r(9332),l=r(9648),a=r(9046),c=r(2087),d=r(7518),h=r.n(d),x=r(214),u=r(1301),C=r(1374),p=r(7026),j=e([l]);l=(j.then?(await j)():j)[0];let g=h().div`
  display: flex;
  flex-direction: column;
  height: 100vh !important;
`,k=h().main`
  flex: 1;
  margin: 2% 5%

`,w=h().section`
  flex: 1;
  margin: 0

`,m=({children:e})=>{let{isAuthenticated:t,loading:r}=(0,p.a)(),s=(0,n.usePathname)(),d=(0,n.useRouter)(),[h,j]=(0,o.useState)(t),[m,f]=(0,o.useState)([]),v=(0,o.useCallback)(async()=>{try{let e=await l.default.get("/api/announcements");f(e.data)}catch(e){console.error("Error fetching announcements")}},[]);return(0,o.useEffect)(()=>{j(t);let e=s.split("/")[1];t&&("login"===e||"register"===e)&&d.push("/")},[t,s,d]),(0,o.useEffect)(()=>{v()},[v]),(0,i.jsxs)(g,{children:[i.jsx(a.Z,{isAuthenticated:h}),i.jsx(x.Z,{}),(0,i.jsxs)(C.J,{children:[m.length>0&&m.map((e,t)=>i.jsx(u.Z,{message:e.message,bkg:"green"===e.color?"green":"red"===e.color?"#A60101":"#B88F27"},t)),i.jsx(k,{children:(0,i.jsxs)("section",{id:"content-wrapper",children:[i.jsx("section",{className:"ad"}),i.jsx(w,{children:e}),i.jsx("section",{className:"ad"})]})})]}),i.jsx(c.Z,{})]})};s()}catch(e){s(e)}})},9529:(e,t,r)=>{"use strict";r.d(t,{Z:()=>x});var s=r(997),i=r(7518),o=r.n(i);let n=o().div`
display: flex;

a *{
    color: black;
    padding: 1%;
    margin: 10px;
    &:hover {
      background-color: #E9E9E9;
      border-radius: 20px;
      transition:200ms;
    }
  }
`,l=({link:e})=>s.jsx("a",{href:`https://www.linkedin.com/${e}`,target:"_blank",children:(0,s.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",width:"24",height:"24",color:"#000000",fill:"none",children:[s.jsx("path",{d:"M4.5 9.5H4C3.05719 9.5 2.58579 9.5 2.29289 9.79289C2 10.0858 2 10.5572 2 11.5V20C2 20.9428 2 21.4142 2.29289 21.7071C2.58579 22 3.05719 22 4 22H4.5C5.44281 22 5.91421 22 6.20711 21.7071C6.5 21.4142 6.5 20.9428 6.5 20V11.5C6.5 10.5572 6.5 10.0858 6.20711 9.79289C5.91421 9.5 5.44281 9.5 4.5 9.5Z",stroke:"currentColor","stroke-width":"1.5"}),s.jsx("path",{d:"M6.5 4.25C6.5 5.49264 5.49264 6.5 4.25 6.5C3.00736 6.5 2 5.49264 2 4.25C2 3.00736 3.00736 2 4.25 2C5.49264 2 6.5 3.00736 6.5 4.25Z",stroke:"currentColor","stroke-width":"1.5"}),s.jsx("path",{d:"M12.326 9.5H11.5C10.5572 9.5 10.0858 9.5 9.79289 9.79289C9.5 10.0858 9.5 10.5572 9.5 11.5V20C9.5 20.9428 9.5 21.4142 9.79289 21.7071C10.0858 22 10.5572 22 11.5 22H12C12.9428 22 13.4142 22 13.7071 21.7071C14 21.4142 14 20.9428 14 20L14.0001 16.5001C14.0001 14.8433 14.5281 13.5001 16.0879 13.5001C16.8677 13.5001 17.5 14.1717 17.5 15.0001V19.5001C17.5 20.4429 17.5 20.9143 17.7929 21.2072C18.0857 21.5001 18.5572 21.5001 19.5 21.5001H19.9987C20.9413 21.5001 21.4126 21.5001 21.7055 21.2073C21.9984 20.9145 21.9985 20.4432 21.9987 19.5006L22.0001 14.0002C22.0001 11.515 19.6364 9.50024 17.2968 9.50024C15.9649 9.50024 14.7767 10.1531 14.0001 11.174C14 10.5439 14 10.2289 13.8632 9.995C13.7765 9.84686 13.6531 9.72353 13.505 9.63687C13.2711 9.5 12.9561 9.5 12.326 9.5Z",stroke:"currentColor","stroke-width":"1.5","stroke-linejoin":"round"})]})}),a=({link:e})=>s.jsx("a",{href:`https://www.instagram.com/${e}`,target:"_blank",children:(0,s.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",width:"24",height:"24",color:"#000000",fill:"none",children:[s.jsx("path",{d:"M2.5 12C2.5 7.52166 2.5 5.28249 3.89124 3.89124C5.28249 2.5 7.52166 2.5 12 2.5C16.4783 2.5 18.7175 2.5 20.1088 3.89124C21.5 5.28249 21.5 7.52166 21.5 12C21.5 16.4783 21.5 18.7175 20.1088 20.1088C18.7175 21.5 16.4783 21.5 12 21.5C7.52166 21.5 5.28249 21.5 3.89124 20.1088C2.5 18.7175 2.5 16.4783 2.5 12Z",stroke:"currentColor","stroke-width":"1.5","stroke-linejoin":"round"}),s.jsx("path",{d:"M16.5 12C16.5 14.4853 14.4853 16.5 12 16.5C9.51472 16.5 7.5 14.4853 7.5 12C7.5 9.51472 9.51472 7.5 12 7.5C14.4853 7.5 16.5 9.51472 16.5 12Z",stroke:"currentColor","stroke-width":"1.5"}),s.jsx("path",{d:"M17.5078 6.5L17.4988 6.5",stroke:"currentColor","stroke-width":"2","stroke-linecap":"round","stroke-linejoin":"round"})]})}),c=({link:e})=>s.jsx("a",{href:`https://youtube.com/${e}`,target:"_blank",children:(0,s.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",width:"24",height:"24",color:"#000000",fill:"none",children:[s.jsx("path",{d:"M12 20.5C13.8097 20.5 15.5451 20.3212 17.1534 19.9934C19.1623 19.5839 20.1668 19.3791 21.0834 18.2006C22 17.0221 22 15.6693 22 12.9635V11.0365C22 8.33073 22 6.97787 21.0834 5.79937C20.1668 4.62088 19.1623 4.41613 17.1534 4.00662C15.5451 3.67877 13.8097 3.5 12 3.5C10.1903 3.5 8.45489 3.67877 6.84656 4.00662C4.83766 4.41613 3.83321 4.62088 2.9166 5.79937C2 6.97787 2 8.33073 2 11.0365V12.9635C2 15.6693 2 17.0221 2.9166 18.2006C3.83321 19.3791 4.83766 19.5839 6.84656 19.9934C8.45489 20.3212 10.1903 20.5 12 20.5Z",stroke:"currentColor","stroke-width":"1.5"}),s.jsx("path",{d:"M15.9621 12.3129C15.8137 12.9187 15.0241 13.3538 13.4449 14.2241C11.7272 15.1705 10.8684 15.6438 10.1728 15.4615C9.9372 15.3997 9.7202 15.2911 9.53799 15.1438C9 14.7089 9 13.8059 9 12C9 10.1941 9 9.29112 9.53799 8.85618C9.7202 8.70886 9.9372 8.60029 10.1728 8.53854C10.8684 8.35621 11.7272 8.82945 13.4449 9.77593C15.0241 10.6462 15.8137 11.0813 15.9621 11.6871C16.0126 11.8933 16.0126 12.1067 15.9621 12.3129Z",stroke:"currentColor","stroke-width":"1.5","stroke-linejoin":"round"})]})}),d=({link:e})=>s.jsx("a",{href:`https://www.tiktok.com/${e}`,target:"_blank",children:(0,s.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",width:"24",height:"24",color:"#000000",fill:"none",children:[s.jsx("path",{d:"M2.5 12C2.5 7.52166 2.5 5.28249 3.89124 3.89124C5.28249 2.5 7.52166 2.5 12 2.5C16.4783 2.5 18.7175 2.5 20.1088 3.89124C21.5 5.28249 21.5 7.52166 21.5 12C21.5 16.4783 21.5 18.7175 20.1088 20.1088C18.7175 21.5 16.4783 21.5 12 21.5C7.52166 21.5 5.28249 21.5 3.89124 20.1088C2.5 18.7175 2.5 16.4783 2.5 12Z",stroke:"currentColor","stroke-width":"1.5","stroke-linejoin":"round"}),s.jsx("path",{d:"M10.5359 11.0075C9.71585 10.8916 7.84666 11.0834 6.93011 12.7782C6.01355 14.4729 6.9373 16.2368 7.51374 16.9069C8.08298 17.5338 9.89226 18.721 11.8114 17.5619C12.2871 17.2746 12.8797 17.0603 13.552 14.8153L13.4738 5.98145C13.3441 6.95419 14.4186 9.23575 17.478 9.5057",stroke:"currentColor","stroke-width":"1.5","stroke-linecap":"round","stroke-linejoin":"round"})]})}),h=({user:e})=>s.jsx("a",{onClick:()=>void(navigator.clipboard.writeText(`https://www.ecotivista.org/users/${e}`),alert(`Usuario copiado: https://www.ecotivista.org/users/${e}`)),children:(0,s.jsxs)("svg",{xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24",width:"24",height:"24",color:"#000000",fill:"none",children:[s.jsx("path",{d:"M20.3927 8.03168L18.6457 6.51461C17.3871 5.42153 16.8937 4.83352 16.2121 5.04139C15.3622 5.30059 15.642 6.93609 15.642 7.48824C14.3206 7.48824 12.9468 7.38661 11.6443 7.59836C7.34453 8.29742 6 11.3566 6 14.6525C7.21697 13.9065 8.43274 13.0746 9.8954 12.7289C11.7212 12.2973 13.7603 12.5032 15.642 12.5032C15.642 13.0554 15.3622 14.6909 16.2121 14.9501C16.9844 15.1856 17.3871 14.5699 18.6457 13.4769L20.3927 11.9598C21.4642 11.0293 22 10.564 22 9.99574C22 9.4275 21.4642 8.96223 20.3927 8.03168Z",stroke:"currentColor","stroke-width":"1.5","stroke-linecap":"round","stroke-linejoin":"round"}),s.jsx("path",{d:"M10.5676 3C6.70735 3.00694 4.68594 3.10152 3.39411 4.39073C2 5.78202 2 8.02125 2 12.4997C2 16.9782 2 19.2174 3.3941 20.6087C4.78821 22 7.03198 22 11.5195 22C16.0071 22 18.2509 22 19.645 20.6087C20.6156 19.64 20.9104 18.2603 21 16",stroke:"currentColor","stroke-width":"1.5","stroke-linecap":"round","stroke-linejoin":"round"})]})});function x({links:e,user:t}){return(0,s.jsxs)(n,{children:[e.linkedIn?s.jsx(l,{link:e.linkedIn}):s.jsx(s.Fragment,{}),e.instagram?s.jsx(a,{link:e.instagram}):s.jsx(s.Fragment,{}),e.yt?s.jsx(c,{link:e.yt}):s.jsx(s.Fragment,{}),e.tiktok?s.jsx(d,{link:e.tiktok}):s.jsx(s.Fragment,{}),t?s.jsx(h,{user:t}):s.jsx(s.Fragment,{})]})}},1301:(e,t,r)=>{"use strict";r.d(t,{Z:()=>a});var s=r(997),i=r(6689),o=r(7518),n=r.n(o);let l=n().div`
width: 100%;
text-align: center;
padding: 1% 3%;
color: white;
display: flex;
justify-content: center;
align-items: center;

button{
margin: 0 2%;
border: 1px solid white;
padding:0 0.3%;
}

button:hover{
border-radius: 20px;
transition:200ms;
}
`,a=({message:e,bkg:t})=>{let[r,o]=(0,i.useState)(!0);return r?(0,s.jsxs)(l,{className:"notification",style:{background:`${t}`},children:[s.jsx("span",{children:e}),s.jsx("button",{className:"close-btn",onClick:()=>{o(!1)},children:"X"})]}):null}},3414:(e,t,r)=>{"use strict";r.a(e,async(e,s)=>{try{r.r(t),r.d(t,{default:()=>d});var i=r(997);r(6764);var o=r(5371),n=r(7026),l=r(968),a=r.n(l),c=e([o]);o=(c.then?(await c)():c)[0];let d=function({Component:e,pageProps:t}){return(0,i.jsxs)(i.Fragment,{children:[i.jsx(a(),{children:i.jsx("link",{rel:"icon",href:"/favicon.ico"})}),i.jsx(n.H,{children:i.jsx(o.Z,{children:i.jsx(e,{...t})})})]})};s()}catch(e){s(e)}})},2457:e=>{"use strict";e.exports={PORT:process.env.PORT,USERDB:process.env.USERDB,PWD:process.env.DBPASSWORD,SECRET:process.env.SECRETKEY,MKEY:process.env.MAILKEY,PATHURL:process.env.NEXT_PUBLIC_REMOTE,allowedDomains:[process.env.REMOTE_CLIENT_APP,process.env.REMOTE_SERVER_API]}},7026:(e,t,r)=>{"use strict";r.d(t,{H:()=>l,a:()=>a});var s=r(997),i=r(6689);let{checkStatus:o}=r(5695),n=(0,i.createContext)(),l=({children:e})=>{let[t,r]=(0,i.useState)(!1),[l,a]=(0,i.useState)(""),[c,d]=(0,i.useState)(""),[h,x]=(0,i.useState)(""),[u,C]=(0,i.useState)(!0);return(0,i.useEffect)(()=>{(async()=>{try{let e=await o();e.isAuthorized?(r(!0),a(e.username),d(e.email),x(e.id)):r(!1)}catch(e){r(!1)}finally{C(!1)}})()},[]),s.jsx(n.Provider,{value:{isAuthenticated:t,setIsAuthenticated:r,username:l,setUsername:a,email:c,setEmail:d,id:h,setId:x,loading:u},children:e})},a=()=>(0,i.useContext)(n)},1374:(e,t,r)=>{"use strict";r.d(t,{u:()=>c,J:()=>d});var s=r(997),i=r(7251),o=r.n(i);let n=({status:e,msj:t})=>s.jsx("div",{className:`${o().notification} ${o()[e]}`,children:s.jsx("p",{children:t})});var l=r(6689);let a={open:!1,status:null,msj:null},c=(0,l.createContext)({}),d=({children:e})=>{let[t,r]=(0,l.useState)(a);return(0,s.jsxs)(c.Provider,{value:{...t,showNotification:e=>{e&&(r(e),setTimeout(()=>{r({open:!1,msj:null,status:null})},6e3))}},children:[e,t.open&&s.jsx(s.Fragment,{children:s.jsx(n,{status:t.status,msj:t.msj})})]})}},5695:(e,t,r)=>{"use strict";r.r(t),r.d(t,{checkStatus:()=>i});let{PATHURL:s}=r(2457);async function i(){try{let e=await fetch(`${s}/api/auth/check`,{credentials:"include"});if(!e.ok)throw Error("Not authorized");let t=await e.json();return{isAuthorized:t.isAuthorized,username:t.username,email:t.email,id:t.id}}catch(e){}}},6764:()=>{}};